from distutils.core import  setup
from setuptools import setup, find_packages
setup(name='mytools',version='0.2',author='Non-Existent987',packages=find_packages())